﻿namespace FinanceTracker.Data
{
    public class Class
    {
    }
}
