﻿namespace FinanceTracker.Controllers
{
    public class Class
    {
    }
}
