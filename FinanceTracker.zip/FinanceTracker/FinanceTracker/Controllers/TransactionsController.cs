﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FinanceTracker.Data;
using FinanceTracker.Models;
using X.PagedList;
using X.PagedList.Extensions;


namespace FinanceTracker.Controllers
{
    public class TransactionsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TransactionsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int? categoryId, DateTime? startDate, DateTime? endDate, string sortOrder, int? page)
        {
            ViewData["AmountSortParm"] = sortOrder == "Amount" ? "amount_desc" : "Amount";
            ViewData["DateSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            var transactions = _context.Transactions.Include(t => t.Category).AsQueryable();

            // Filtering
            if (categoryId.HasValue)
                transactions = transactions.Where(t => t.CategoryId == categoryId.Value);

            if (startDate.HasValue)
                transactions = transactions.Where(t => t.Date >= startDate.Value);

            if (endDate.HasValue)
                transactions = transactions.Where(t => t.Date <= endDate.Value);

            // Sorting
            transactions = sortOrder switch
            {
                "Amount" => transactions.OrderBy(t => t.Amount),
                "amount_desc" => transactions.OrderByDescending(t => t.Amount),
                "Date" => transactions.OrderBy(t => t.Date),
                "date_desc" => transactions.OrderByDescending(t => t.Date),
                _ => transactions.OrderByDescending(t => t.Date)
            };

            // Dropdown filter
            ViewBag.Categories = new SelectList(await _context.Categories.ToListAsync(), "Id", "Title");

            // Pagination
            int pageSize = 5;
            int pageNumber = page ?? 1;

            return View(transactions.ToPagedList(pageNumber, pageSize));

        }

        public IActionResult Create()
        {
            ViewBag.CategoryId = new SelectList(_context.Categories, "Id", "Title");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,CategoryId,Amount,Note,Date")] Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                _context.Add(transaction);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.CategoryId = new SelectList(_context.Categories, "Id", "Title", transaction.CategoryId);
            return View(transaction);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var transaction = await _context.Transactions.FindAsync(id);
            if (transaction == null) return NotFound();

            ViewBag.CategoryId = new SelectList(_context.Categories, "Id", "Title", transaction.CategoryId);
            return View(transaction);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Transaction transaction)
        {
            if (id != transaction.Id) return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(transaction);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.CategoryId = new SelectList(_context.Categories, "Id", "Title", transaction.CategoryId);
            return View(transaction);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var transaction = await _context.Transactions
                .Include(t => t.Category)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (transaction == null) return NotFound();

            return View(transaction);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var transaction = await _context.Transactions.FindAsync(id);
            if (transaction != null)
            {
                _context.Transactions.Remove(transaction);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Summary()
        {
            var transactions = await _context.Transactions.Include(t => t.Category).ToListAsync();
            return View(transactions);
        }
    }
}
