﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FinanceTracker.Models
{
    public class Transaction
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Category")]
        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public Category? Category { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [Required]
        public string Note { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        public DateTime Date { get; set; }
    }
}
