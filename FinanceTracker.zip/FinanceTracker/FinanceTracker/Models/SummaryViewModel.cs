﻿namespace FinanceTracker.Models
{
    public class SummaryViewModel
    {
        public decimal TotalIncome { get; set; }
        public decimal TotalExpense { get; set; }
        public decimal Balance => TotalIncome - TotalExpense;
        public List<Transaction> RecentTransactions { get; set; } = new();
    }
}
